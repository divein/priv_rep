/* 
 * 发条网核心js文件
 * 
 * 网站核心js文件，使用其他js前必须包含此文件
 * 
 * @author Wangxinyi <divein@126.com>
 * @version $Id$
 * @package core
 */

/**
 * Jquery 插件
 */
$.fn.extend();

